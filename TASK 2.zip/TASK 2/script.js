// script.js
const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');

let currentValue = '';
let previousValue = '';
let operator = '';

buttons.forEach(button => {
    button.addEventListener('click', () => {
        const action = button.dataset.action;
        const number = button.dataset.number;

        if (number) {
            handleNumber(number);
        } else if (action) {
            handleAction(action);
        }
    });
});

function handleNumber(number) {
    if (currentValue.length >= 10) return;
    currentValue += number;
    display.innerText = currentValue;
}

function handleAction(action) {
    switch (action) {
        case 'clear':
            clearCalculator();
            break;
        case 'plus-minus':
            currentValue = (-parseFloat(currentValue)).toString();
            display.innerText = currentValue;
            break;
        case 'percent':
            currentValue = (parseFloat(currentValue) / 100).toString();
            display.innerText = currentValue;
            break;
        case 'add':
        case 'subtract':
        case 'multiply':
        case 'divide':
            handleOperator(action);
            break;
        case 'calculate':
            calculate();
            break;
        case 'decimal':
            if (!currentValue.includes('.')) {
                currentValue += '.';
                display.innerText = currentValue;
            }
            break;
    }
}

function clearCalculator() {
    currentValue = '';
    previousValue = '';
    operator = '';
    display.innerText = '0';
}

function handleOperator(action) {
    if (currentValue === '') return;
    if (previousValue !== '') {
        calculate();
    }
    operator = action;
    previousValue = currentValue;
    currentValue = '';
}

function calculate() {
    let result;
    const previous = parseFloat(previousValue);
    const current = parseFloat(currentValue);

    if (isNaN(previous) || isNaN(current)) return;

    switch (operator) {
        case 'add':
            result = previous + current;
            break;
        case 'subtract':
            result = previous - current;
            break;
        case 'multiply':
            result = previous * current;
            break;
        case 'divide':
            result = previous / current;
            break;
    }

    currentValue = result.toString().slice(0, 10);
    operator = '';
    previousValue = '';
    display.innerText = currentValue;
}
