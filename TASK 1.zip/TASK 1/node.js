const search = document.querySelector(".search-box input"),
      images = document.querySelectorAll(".image-box");

search.addEventListener("keyup", e => {
    if (e.key === "Enter" || e.key === "Return") {  // "Return" for some older browsers or keyboard layouts
        let searchValue = search.value.trim().toLowerCase();
        images.forEach(image => {
            if (searchValue === image.dataset.name.toLowerCase()) {
                image.style.display = "block";
            } else {
                image.style.display = "none";
            }
        });
    }
});

search.addEventListener("keyup", () => {
    if (search.value.trim() === "") {
        images.forEach(image => {
            image.style.display = "block";
        });
    }
});
